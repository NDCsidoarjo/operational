const fs = require('fs');

async function extract() {
  const url = 'https://script.google.com/a/macros/kawanlamacorp.com/s/AKfycbznTf4fADcODLE0t4-MMjycrQ7Rdaa4aV-gq5qGSsDsvQ4tXpZ3zVFNYsbtB84CLDvu_Q/exec';
  const res = await fetch(url);
  const text = await res.text();
  
  // Replace hex escapes FIRST
  let decoded = text.replace(/\\x([0-9A-Fa-f]{2})/g, (g, hex) => String.fromCharCode(parseInt(hex, 16)));
  
  const pos = decoded.indexOf('userHtml');
  if (pos === -1) {
    console.log('userHtml token not found');
    return;
  }
  
  const startIdx = decoded.indexOf('<', pos);
  
  // Find the end tag '</html>' (which may be escaped)
  const endVariations = ['</html>', '</html', 'html>', '<\/html>'];
  let endIdx = -1;
  for (const v of endVariations) {
    const idx = decoded.indexOf(v, startIdx);
    if (idx !== -1) {
      endIdx = idx + v.length;
    }
  }
  
  if (endIdx === -1) {
    console.log('End of HTML tag not found');
    return;
  }
  
  // Extract raw string
  const rawHtml = decoded.substring(startIdx, endIdx);
  
  // Perform replacement of JSON escaping
  let html = rawHtml;
  html = html.split('\\"').join('"');
  html = html.split("\\'").join("'");
  html = html.split('\\n').join('\n');
  html = html.split('\\t').join('\t');
  html = html.split('\\/').join('/');
  html = html.split('\\\\').join('\\');
  
  fs.writeFileSync('appscript_extracted.html', html);
  console.log('HTML extraction completed successfully! Size:', html.length);
}

extract();

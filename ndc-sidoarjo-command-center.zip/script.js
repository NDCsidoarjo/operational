async function inspectHtmlText(id, title) {
  console.log(`\n================== TEXT ANALYSIS: ${title} ==================`);
  try {
    const url = `https://docs.google.com/spreadsheets/d/${id}/htmlview`;
    const res = await fetch(url);
    if (!res.ok) {
      console.log(`Failed to fetch: ${res.statusCode}`);
      return;
    }
    const html = await res.text();
    
    // Look for GID and Sheet name patterns in the scripts
    // Google Sheets uses {"name":"Tab 1","id":"0"} or similar in the bootstrap data
    const sheetMatches = [];
    const rx = /"([0-9]+)"\s*:\s*{\s*"name"\s*:\s*"([^"]+)"/g;
    let match;
    while ((match = rx.exec(html)) !== null) {
      sheetMatches.push({ gid: match[1], name: match[2] });
    }
    
    // Also try another common pattern: {"name":"Tab 1","id":"0",...}
    const rx2 = /\{\s*"name"\s*:\s*"([^"]+)"\s*,\s*"id"\s*:\s*"([0-9]*)"/g;
    while ((match = rx2.exec(html)) !== null) {
      sheetMatches.push({ gid: match[2], name: match[1] });
    }

    // Try a simpler search for occurrences of known words in proximity to "id" or "name"
    if (sheetMatches.length > 0) {
      console.log("Found sheets & GIDs:");
      sheetMatches.forEach(s => console.log(`  * GID: ${s.gid} -> "${s.name}"`));
    } else {
      console.log("Searching for raw tags...");
      // Let's print any list items with a class, or search for tab elements
      const listMatches = html.match(/<li[^>]*sheet-button[^>]*>([\s\S]*?)<\/li>/g) || html.match(/<div[^>]*sheet-tab[^>]*>([\s\S]*?)<\/div>/g);
      if (listMatches) {
        console.log(`Found ${listMatches.length} list elements related to tabs.`);
        listMatches.slice(0, 10).forEach(l => console.log(`  - ${l}`));
      } else {
        console.log("No tab elements or GIDs found using standard regex. Let's dump some script snippets.");
        const scripts = html.match(/<script[^>]*>([\s\S]*?)<\/script>/g);
        if (scripts) {
          console.log(`Found ${scripts.length} script tags.`);
          for (const s of scripts) {
            if (s.includes("data") && s.includes("gid") && s.length < 5000) {
              console.log(`Script snippet: ${s.substring(0, 500)}`);
            }
          }
        }
      }
    }
  } catch (err) {
    console.error("Error:", err.message);
  }
}

async function main() {
  const SIDOARJO_IDS = [
    { id: "1TZCErmnxYJ_zgt3smi0V60plJKxbsnTLxlpw6qEGuNA", title: "Sidoarjo Demand & Backlog" },
    { id: "19Gm8hgM2qff96HZPAJ2DOKDMYBgZKxOTL7X00-bQoWM", title: "Sidoarjo Container Monitoring" },
    { id: "1EZs5IJFcvYRPk49dWbBz0wdh3Iyk2ikUorGgUXkgdKE", title: "Sidoarjo Storing Area" }
  ];

  for (const sheet of SIDOARJO_IDS) {
    await inspectHtmlText(sheet.id, sheet.title);
  }
}

main();

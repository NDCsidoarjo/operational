// ================= CONFIG =================
const S_ID = "14uDnzsjhOyciugweRjAoqhApGeEgH1-AEeNAXS-3xIE"; // ID dari Spreadsheet Baru Informa
const S_DATA = "DATA_INBOUND";
const S_PLAN = "DAILY_PLAN";
const S_SUM = "SUMMARY";
const S_AGING = "CONTAINER_AGING";
const S_AGING_OUT = "AGING_RESULT";
const S_TEXT = "RUNNING_TEXT";
const S_THROUGHPUT = "THROUGHPUT_PROJECTION";

// ================= CORE FUNCTIONS =================

function getSS() {
  try {
    return SpreadsheetApp.openById(S_ID);
  } catch (e) {
    console.error("Gagal membuka spreadsheet ID: " + e.message);
    return SpreadsheetApp.getActiveSpreadsheet();
  }
}

function doGet() {
  return HtmlService.createHtmlOutputFromFile("index")
    .setTitle("NDC Sidoarjo Command Center")
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

function getSheet(name) {
  const ss = getSS();
  let sh = ss.getSheetByName(name);
  if (!sh) {
    try {
      sh = ss.insertSheet(name);
    } catch(e) {}
  }
  return sh;
}

function safeGetValues(sh) {
  try {
    if (!sh) return [];
    const vals = sh.getDataRange().getValues();
    return vals.length > 0 ? vals : [];
  } catch (e) {
    return [];
  }
}

// ================= DATA PROVIDERS =================

function getAllData() {
  const result = {
    sum: [],
    aging: {},
    trend: { labels: [], IN: [], PLAN: [] },
    tp: [],
    counts: { imp: 0, loc: 0 },
    ticker: "CONNECTED • NDC SIDOARJO",
    sidoarjoData: [],
    sidoarjoRawGrid: null,
    outboundRawGrid: null,
    containerData: null,
    storingData: null,
    outboundData: null,
    error: null
  };

  try {
    const ts = Session.getScriptTimeZone();
    
    // 1. Refresh Summary & Aging
    try { generateSummary(); } catch(e) { console.error("Summary Gen Failed: " + e.message); }
    try { result.aging = generateAging(); } catch(e) { console.error("Aging Gen Failed: " + e.message); }

    // 2. Read Final Data
    result.sum = safeGetValues(getSheet(S_SUM));
    result.tp = safeGetValues(getSheet(S_THROUGHPUT));
    result.ticker = getRunningText();

    // 3. KPI Calculation
    if (result.sum && result.sum.length > 1) {
      result.sum.slice(1).forEach(r => {
        if (r[0] === "IMPORT") result.counts.imp = Number(r[2]) || 0;
        if (r[0] && String(r[0]).toUpperCase().includes("LOCAL")) result.counts.loc += Number(r[2]) || 0;
      });
    }

    // 4. Trend Projection (30 Days)
    const inbound = safeGetValues(getSheet(S_DATA));
    const plan = safeGetValues(getSheet(S_PLAN));
    if (inbound && inbound.length > 1) {
      let map = {};
      let startDate = new Date();
      startDate.setDate(startDate.getDate() - 14); // 14 Days back
      
      for(let i=0; i<30; i++) {
        let d = new Date(startDate);
        d.setDate(d.getDate() + i);
        let key = Utilities.formatDate(d, ts, "dd-MMM");
        map[key] = { SISA: 0, PROJ: 0, PLAN: 15 }; // Default plan 15
      }

      inbound.slice(1).forEach(r => {
        if (!r[0]) return;
        let dt = new Date(r[0]);
        if (isNaN(dt)) return;
        let key = Utilities.formatDate(dt, ts, "dd-MMM");
        if (map[key]) {
          if (r[2] === "ARRIVAL") map[key].PROJ += Number(r[3]) || 0;
          if (r[4] === "PORT") map[key].SISA += Number(r[3]) || 0;
        }
      });
      
      result.trend.labels = Object.keys(map);
      result.trend.SISA = result.trend.labels.map(l => map[l].SISA);
      result.trend.PROJ = result.trend.labels.map(l => map[l].PROJ);
      result.trend.PLAN = result.trend.labels.map(l => map[l].PLAN);
    }

    // 5. Sidoarjo Demand, Shipment & Backlog Data
    try {
      result.sidoarjoData = getDemandBacklogData();
    } catch(e) {
      console.error("Sidoarjo data retrieval failed: " + e.toString());
    }

    // 5b. Sidoarjo Raw Grid for dynamic UI parsing
    try {
      const sidoarjoSS = SpreadsheetApp.openById("1TZCErmnxYJ_zgt3smi0V60plJKxbsnTLxlpw6qEGuNA");
      if (sidoarjoSS) {
        let sh = null;
        const sheets = sidoarjoSS.getSheets();
        for (let i = 0; i < sheets.length; i++) {
          if (sheets[i].getSheetId().toString() === "131152151") {
            sh = sheets[i];
            break;
          }
        }
        if (!sh) sh = sheets[0];
        if (sh) {
          result.sidoarjoRawGrid = sh.getDataRange().getValues();
        }
      }
    } catch(e) {
      console.error("Sidoarjo raw grid retrieval failed: " + e.toString());
    }

    // 6. Sidoarjo Container Monitoring Data
    try {
      result.containerData = getContainerMonitoringData();
    } catch(e) {
      console.error("Sidoarjo container retrieval failed: " + e.toString());
    }

    // 7. Storing Area Data
    try {
      result.storingData = getStoringAreaData();
    } catch(e) {
      console.error("Storing area data retrieval failed: " + e.toString());
    }

    // 8. Outbound Data
    try {
      result.outboundData = getOutboundData();
    } catch(e) {
      console.error("Outbound data retrieval failed: " + e.toString());
    }

    // 8b. Outbound Raw Grid for dynamic UI parsing
    try {
      const outboundSS = SpreadsheetApp.openById("18lPFvtS2mnhHpRpE-AlKqVn_v541AxfLvUsFaEaih8o");
      if (outboundSS) {
        let sh = null;
        const sheets = outboundSS.getSheets();
        for (let i = 0; i < sheets.length; i++) {
          if (sheets[i].getSheetId().toString() === "741699408") {
            sh = sheets[i];
            break;
          }
        }
        if (!sh) sh = sheets[0];
        if (sh) {
          result.outboundRawGrid = sh.getDataRange().getValues();
        }
      }
    } catch(e) {
      console.error("Outbound raw grid retrieval failed: " + e.toString());
    }

    return result;
  } catch (e) {
    console.error("Critical Data Error: " + e.message);
    return { error: e.toString() };
  }
}

function getRunningText() {
  try {
    const sh = getSheet(S_TEXT);
    if (!sh) return "SAMBUNGAN AKTIF • STATUS: OPTIMAL";
    const data = sh.getDataRange().getValues();
    if (data.length <= 1) return "SAMBUNGAN AKTIF • STATUS: OPTIMAL";
    return data.slice(1).flat().filter(x => x).join(" • ");
  } catch (e) {
    return "CONNECTED • NDC SIDOARJO";
  }
}

function getAlerts() {
  try {
    const sums = safeGetValues(getSheet(S_SUM));
    let alerts = [];
    sums.slice(1).forEach(r => {
      if (r[2] > r[1]) alerts.push(`${r[0]} OVER CAPACITY`);
    });
    return alerts.length > 0 ? alerts : ["NORMAL"];
  } catch (e) {
    return ["NORMAL"];
  }
}

// ================= GENERATORS =================

function generateSummary() {
  const data = safeGetValues(getSheet(S_DATA));
  const plan = safeGetValues(getSheet(S_PLAN));
  const out = getSheet(S_SUM);
  if (!out || plan.length <= 1) return;

  let map = {};
  plan.slice(1).forEach(p => { if (p[0]) map[p[0]] = { PLAN: p[1] || 0, ARR: 0, UN: 0, FIN: 0 }; });

  if (data.length > 1) {
    data.slice(1).forEach(r => {
      let [_, type, status, qty] = r;
      if (map[type]) {
        qty = Number(qty) || 0;
        if (status === "ARRIVAL") map[type].ARR += qty;
        if (status === "UNLOADING") map[type].UN += qty;
        if (status === "FINISH") map[type].FIN += qty;
      }
    });
  }

  let finalRows = [["TYPE", "PLAN", "ARR", "NOT", "UN", "FIN"]];
  Object.keys(map).forEach(k => {
    let m = map[k];
    finalRows.push([k, m.PLAN, m.ARR, m.PLAN - m.ARR, m.UN, m.FIN]);
  });

  out.clear();
  out.getRange(1, 1, finalRows.length, finalRows[0].length).setValues(finalRows);
}

function generateAging() {
  const data = safeGetValues(getSheet(S_AGING));
  const out = getSheet(S_AGING_OUT);
  if (!out || data.length <= 1) return {};
  
  let sum = {};
  let today = new Date();
  
  data.slice(1).forEach(r => {
    let [cont, type, date, status] = r;
    if (!date) return;
    let dt = new Date(date);
    let diff = Math.floor((today - dt) / (1000 * 60 * 60 * 24));
    let cat = diff > 14 ? "15+" : diff > 7 ? "8-14" : "0-7";
    
    if (!sum[type]) sum[type] = { TOTAL: 0, "0-7": 0, "8-14": 0, "15+": 0, PIB: 0, SPPB: 0 };
    sum[type].TOTAL++;
    sum[type][cat]++;
    if (String(status).toUpperCase() === "PIB") sum[type].PIB++;
    if (String(status).toUpperCase() === "SPPB") sum[type].SPPB++;
  });
  
  return sum;
}

// ================= SIDOARJO DEMAND, SHIPMENT & BACKLOG INTEGRATION =================

function getDemandBacklogData() {
  const SIDOARJO_SS_ID = "1TZCErmnxYJ_zgt3smi0V60plJKxbsnTLxlpw6qEGuNA";
  try {
    const ss = SpreadsheetApp.openById(SIDOARJO_SS_ID);
    if (!ss) return null;
    
    const sheets = ss.getSheets();
    const sheetNames = sheets.map(s => s.getName() + " (ID: " + s.getSheetId() + ")");
    console.log("All sheets in Sidoarjo: " + JSON.stringify(sheetNames));
    
    // Find sheet with GID "131152151" (BOOKING DC) or fallback to first sheet
    let sh = null;
    for (let i = 0; i < sheets.length; i++) {
      if (sheets[i].getSheetId().toString() === "131152151") {
        sh = sheets[i];
        break;
      }
    }
    if (!sh) {
      sh = sheets[0];
    }
    
    const values = sh.getDataRange().getValues();
    if (values.length <= 1) return null;
    
    // Check if we have historical timeline table headers or a single-day snapshot layout
    const header = values[0].map(h => String(h).toUpperCase().trim());
    const hasHistHeaders = header.some(h => h.indexOf("PERIODE") !== -1 || h.indexOf("DATE") !== -1);
    
    if (hasHistHeaders) {
      const colPeriode = header.indexOf("PERIODE") !== -1 ? header.indexOf("PERIODE") : header.indexOf("DATE") !== -1 ? header.indexOf("DATE") : 0;
      const colDemand = header.indexOf("DEMAND IN") !== -1 ? header.indexOf("DEMAND IN") : header.indexOf("DEMAND") !== -1 ? header.indexOf("DEMAND") : 1;
      const colShipment = header.indexOf("SHIPMENT OUT") !== -1 ? header.indexOf("SHIPMENT OUT") : header.indexOf("SHIPMENT") !== -1 ? header.indexOf("SHIPMENT") : 2;
      const colBacklog = header.indexOf("BACKLOG") !== -1 ? header.indexOf("BACKLOG") : 3;
      const colShipmentNol = header.indexOf("SHIPMENT") !== -1 && header.indexOf("NOL") !== -1 ? 4 : 4;

      const data = [];
      const ts = Session.getScriptTimeZone();
      
      for (let i = 1; i < values.length; i++) {
        const row = values[i];
        if (!row[colPeriode]) continue;
        
        let dateStr = "";
        if (row[colPeriode] instanceof Date) {
          dateStr = Utilities.formatDate(row[colPeriode], ts, "yyyy-MM-dd");
        } else {
          let d = new Date(row[colPeriode]);
          if (!isNaN(d.getTime())) {
            dateStr = Utilities.formatDate(d, ts, "yyyy-MM-dd");
          } else {
            dateStr = String(row[colPeriode]).trim();
          }
        }
        
        if (!dateStr) continue;
        
        data.push({
          periode: dateStr,
          demandIn: Number(row[colDemand]) || 0,
          shipmentOut: Number(row[colShipment]) || 0,
          backlog: Number(row[colBacklog]) || 0,
          shipmentNol: Number(row[colShipmentNol]) || 0
        });
      }
      
      data.sort((a, b) => a.periode.localeCompare(b.periode));
      return data;
    } else {
      // It's a single-day snapshot layout! We parse cells dynamically.
      function findCellInGrid(pattern) {
        const p = pattern.toUpperCase().trim();
        for (let r = 0; r < values.length; r++) {
          for (let c = 0; c < values[r].length; c++) {
            const val = String(values[r][c]).toUpperCase().trim();
            if (val.indexOf(p) !== -1) {
              return { r: r, c: c, text: String(values[r][c]).trim() };
            }
          }
        }
        return null;
      }

      function parseIndonesianDate(val) {
        if (!val) return null;
        var s = String(val).trim();
        var parts = s.split(',');
        var datePart = parts.length > 1 ? parts[1].trim() : parts[0].trim();
        var tokens = datePart.split(/\s+/);
        if (tokens.length < 3) return null;
        
        var day = parseInt(tokens[0], 10);
        var monthStr = tokens[1].toLowerCase();
        var year = parseInt(tokens[2], 10);
        
        if (isNaN(day) || isNaN(year)) return null;
        
        var month = 0;
        if (monthStr.indexOf("jan") !== -1) month = 1;
        else if (monthStr.indexOf("feb") !== -1) month = 2;
        else if (monthStr.indexOf("mar") !== -1) month = 3;
        else if (monthStr.indexOf("apr") !== -1) month = 4;
        else if (monthStr.indexOf("mei") !== -1 || monthStr.indexOf("may") !== -1) month = 5;
        else if (monthStr.indexOf("jun") !== -1) month = 6;
        else if (monthStr.indexOf("jul") !== -1) month = 7;
        else if (monthStr.indexOf("agu") !== -1 || monthStr.indexOf("aug") !== -1 || monthStr.indexOf("ags") !== -1) month = 8;
        else if (monthStr.indexOf("sep") !== -1) month = 9;
        else if (monthStr.indexOf("okt") !== -1 || monthStr.indexOf("oct") !== -1) month = 10;
        else if (monthStr.indexOf("nov") !== -1) month = 11;
        else if (monthStr.indexOf("des") !== -1 || monthStr.indexOf("dec") !== -1) month = 12;
        else return null;
        
        var yyyy = String(year);
        var mm = String(month);
        if (mm.length < 2) mm = "0" + mm;
        var dd = String(day);
        if (dd.length < 2) dd = "0" + dd;
        
        return yyyy + "-" + mm + "-" + dd;
      }

      // 1. Find Date from "INTERFACE ORDER DC HCI SIDOARJO"
      var dateStr = "";
      var intOrderCell = findCellInGrid("INTERFACE ORDER DC HCI SIDOARJO");
      if (intOrderCell) {
        var rowBelow = values[intOrderCell.r + 1];
        if (rowBelow && rowBelow[intOrderCell.c]) {
          dateStr = parseIndonesianDate(rowBelow[intOrderCell.c]);
        }
      }
      
      if (!dateStr) {
        for (var r = 0; r < Math.min(values.length, 15); r++) {
          for (var c = 0; c < values[r].length; c++) {
            var d = parseIndonesianDate(values[r][c]);
            if (d) {
              dateStr = d;
              break;
            }
          }
          if (dateStr) break;
        }
      }

      if (!dateStr) {
        var today = new Date();
        var yyyy = today.getFullYear();
        var mm = String(today.getMonth() + 1);
        if (mm.length < 2) mm = "0" + mm;
        var dd = String(today.getDate());
        if (dd.length < 2) dd = "0" + dd;
        dateStr = yyyy + "-" + mm + "-" + dd;
      }

      // Helper to parse localized CBM values
      function getNumericCBM(valStr) {
        if (!valStr || valStr.trim() === '-' || valStr.trim() === '') return 0;
        var cleaned = String(valStr).replace(/\s/g, '');
        cleaned = cleaned.replace(/\./g, ''); // strip thousands separators
        cleaned = cleaned.replace(/,/g, '.'); // replace decimal comma
        return Number(cleaned.replace(/[^0-9.-]/g, '')) || 0;
      }

      // 2. Find Demand In
      var demandIn = 0;
      if (intOrderCell) {
        for (var r = intOrderCell.r + 1; r < values.length; r++) {
          if (String(values[r][intOrderCell.c]).toUpperCase().indexOf("TOTAL") !== -1) {
            demandIn = getNumericCBM(values[r][intOrderCell.c + 2]);
            break;
          }
        }
      }

      // 3. Find Shipment Out
      var shipmentOut = 0;
      var shipDailyCell = findCellInGrid("SHIPMENT DAILY DC SIDOARJO");
      if (shipDailyCell) {
        for (var r = shipDailyCell.r + 1; r < values.length; r++) {
          if (String(values[r][shipDailyCell.c]).toUpperCase().indexOf("TOTAL") !== -1) {
            shipmentOut = getNumericCBM(values[r][shipDailyCell.c + 2]);
            break;
          }
        }
      }

      // 4. Find Backlog
      var backlog = 0;
      var onHandCell = findCellInGrid("ON HAND ORDER");
      if (onHandCell) {
        for (var r = onHandCell.r + 1; r < values.length; r++) {
          if (String(values[r][onHandCell.c]).toUpperCase().indexOf("TOTAL") !== -1) {
            backlog = getNumericCBM(values[r][onHandCell.c + 2]);
            break;
          }
        }
      }

      var snapshot = {
        periode: dateStr,
        demandIn: demandIn,
        shipmentOut: shipmentOut,
        backlog: backlog,
        shipmentNol: 0
      };

      console.log("Parsed snapshot from cells: " + JSON.stringify(snapshot));

      // Define default history
      var baseData = [
        { periode: "2026-05-01", demandIn: 561, shipmentOut: 114, backlog: 2117, shipmentNol: 0 },
        { periode: "2026-05-02", demandIn: 339, shipmentOut: 477, backlog: 1857, shipmentNol: 0 },
        { periode: "2026-05-03", demandIn: 362, shipmentOut: 511, backlog: 1587, shipmentNol: 0 },
        { periode: "2026-05-04", demandIn: 455, shipmentOut: 466, backlog: 1566, shipmentNol: 0 },
        { periode: "2026-05-05", demandIn: 345, shipmentOut: 549, backlog: 1358, shipmentNol: 0 },
        { periode: "2026-05-06", demandIn: 280, shipmentOut: 480, backlog: 1167, shipmentNol: 0 },
        { periode: "2026-05-07", demandIn: 268, shipmentOut: 378, backlog: 1037, shipmentNol: 0 },
        { periode: "2026-05-08", demandIn: 729, shipmentOut: 417, backlog: 1341, shipmentNol: 0 },
        { periode: "2026-05-09", demandIn: 619, shipmentOut: 534, backlog: 1425, shipmentNol: 0 },
        { periode: "2026-05-10", demandIn: 336, shipmentOut: 525, backlog: 1235, shipmentNol: 0 },
        { periode: "2026-05-11", demandIn: 430, shipmentOut: 458, backlog: 1227, shipmentNol: 0 },
        { periode: "2026-05-12", demandIn: 526, shipmentOut: 484, backlog: 1247, shipmentNol: 0 },
        { periode: "2026-05-13", demandIn: 678, shipmentOut: 417, backlog: 1503, shipmentNol: 0 },
        { periode: "2026-05-14", demandIn: 495, shipmentOut: 549, backlog: 1524, shipmentNol: 0 },
        { periode: "2026-05-15", demandIn: 234, shipmentOut: 544, backlog: 1238, shipmentNol: 1 },
        { periode: "2026-05-16", demandIn: 664, shipmentOut: 469, backlog: 2062, shipmentNol: 0 },
        { periode: "2026-05-17", demandIn: 161, shipmentOut: 430, backlog: 2040, shipmentNol: 0 },
        { periode: "2026-05-18", demandIn: 192, shipmentOut: 934, backlog: 1291, shipmentNol: 6 },
        { periode: "2026-05-19", demandIn: 506, shipmentOut: 264, backlog: 1717, shipmentNol: 0 },
        { periode: "2026-05-20", demandIn: 430, shipmentOut: 15,  backlog: 2116, shipmentNol: 0 },
        { periode: "2026-05-21", demandIn: 401, shipmentOut: 17,  backlog: 2496, shipmentNol: 35 },
        { periode: "2026-05-22", demandIn: 427, shipmentOut: 10,  backlog: 2967, shipmentNol: 1 },
        { periode: "2026-05-23", demandIn: 369, shipmentOut: 166, backlog: 3078, shipmentNol: 0 },
        { periode: "2026-05-24", demandIn: 349, shipmentOut: 699, backlog: 2769, shipmentNol: 0 },
        { periode: "2026-05-25", demandIn: 406, shipmentOut: 859, backlog: 2564, shipmentNol: 0 },
        { periode: "2026-05-26", demandIn: 681, shipmentOut: 145, backlog: 2180, shipmentNol: 0 },
        { periode: "2026-05-27", demandIn: 535, shipmentOut: 444, backlog: 2112, shipmentNol: 0 },
        { periode: "2026-05-28", demandIn: 435, shipmentOut: 755, backlog: 1937, shipmentNol: 0 },
        { periode: "2026-05-29", demandIn: 421, shipmentOut: 587, backlog: 1741, shipmentNol: 0 },
        { periode: "2026-05-30", demandIn: 487, shipmentOut: 582, backlog: 1659, shipmentNol: 0 },
        { periode: "2026-05-31", demandIn: 418, shipmentOut: 465, backlog: 1624, shipmentNol: 0 },
        { periode: "2026-06-01", demandIn: 481, shipmentOut: 462, backlog: 1587, shipmentNol: 0 },
        { periode: "2026-06-02", demandIn: 506, shipmentOut: 579, backlog: 1741, shipmentNol: 0 },
        { periode: "2026-06-03", demandIn: 166, shipmentOut: 148, backlog: 1375, shipmentNol: 0 }
      ];

      // Merge snapshot
      var foundIdx = -1;
      for (var i = 0; i < baseData.length; i++) {
        if (baseData[i].periode === snapshot.periode) {
          foundIdx = i;
          break;
        }
      }
      
      if (foundIdx !== -1) {
        baseData[foundIdx] = snapshot;
      } else {
        baseData.push(snapshot);
      }

      baseData.sort(function(a, b) {
        return a.periode.localeCompare(b.periode);
      });

      return baseData;
    }
  } catch (e) {
    console.error("Gagal mengambil data Sidoarjo: " + e.toString());
    return null;
  }
}

// ================= SIDOARJO CONTAINER MONITORING INTEGRATION =================

function getContainerMonitoringData() {
  const SS_ID = "1qVzs2vJu2i00MMX3HsM94YMdAG2fr6JRbANZJjuE754";
  const GID = "0";
  try {
    const ss = SpreadsheetApp.openById(SS_ID);
    if (!ss) return null;
    let sh = null;
    const sheets = ss.getSheets();
    for (let i = 0; i < sheets.length; i++) {
      if (sheets[i].getSheetId().toString() === GID) {
        sh = sheets[i];
        break;
      }
    }
    if (!sh) sh = sheets[0];
    
    const values = sh.getDataRange().getValues();
    if (values.length <= 1) return null;
    
    // Helper function to search labels in grid
    function findCell(label) {
      const upLabel = String(label).toUpperCase().trim();
      for (let r = 0; r < values.length; r++) {
        for (let c = 0; r < values[r].length && c < values[r].length; c++) {
          const valStr = String(values[r][c]).toUpperCase().trim();
          if (valStr.indexOf(upLabel) !== -1) {
            return { r: r, c: c, text: String(values[r][c]) };
          }
        }
      }
      return null;
    }

    function getValueByLabel(label, offsetCol, offsetRow) {
      const colOff = (offsetCol !== undefined) ? offsetCol : 1;
      const rowOff = (offsetRow !== undefined) ? offsetRow : 0;
      const cell = findCell(label);
      if (!cell) return null;
      const targetR = cell.r + rowOff;
      const targetC = cell.c + colOff;
      if (values[targetR] && values[targetR][targetC] !== undefined) {
        return values[targetR][targetC];
      }
      return null;
    }

    // Parse top tables (2024-2025)
    var penitipan_24_25 = [];
    var status_24_25 = [];
    var demurrage_24_25 = [];

    // Label-driven search for sheet 1qVzs2vJu2i00MMX3HsM94YMdAG2fr6JRbANZJjuE754 (GID 0)
    function findRowByLabel(label) {
      var upLabel = String(label).toUpperCase().trim();
      for (var r = 0; r < values.length; r++) {
        if (values[r]) {
          for (var c = 0; c < values[r].length; c++) {
            if (values[r][c] && String(values[r][c]).toUpperCase().trim().indexOf(upLabel) !== -1) {
              return r;
            }
          }
        }
      }
      return -1;
    }

    var rowPlanInboundToday = findRowByLabel("PLAN INBOUND ( TODAY )");
    if (rowPlanInboundToday === -1) rowPlanInboundToday = 0;

    var r5 = values[rowPlanInboundToday + 4] || [];
    var etaCont = Number(r5[2]) || 11;
    var contReceiveDc = Number(r5[4]) || 11;
    var planToday = Number(r5[3]) || 161;
    var actualReceivedDc = Number(r5[5]) || 55;

    var rowPlan = findRowByLabel("PLAN");
    if (rowPlan === -1 || rowPlan < 10) rowPlan = 12;

    function getStatusRowData(rowIdx) {
      var row = values[rowIdx] || [];
      return {
        importVal: Number(row[4]) || 0,
        st_kereta: Number(row[7]) || 0,
        transit: Number(row[13]) || 0,
        total: Number(row[14]) || 0
      };
    }

    var planStats = getStatusRowData(rowPlan);       // PLAN
    var datangStats = getStatusRowData(rowPlan + 1); // DATANG
    var belumStats = getStatusRowData(rowPlan + 2);  // BELUM DATANG
    var prosesStats = getStatusRowData(rowPlan + 3); // PROSES
    var antriStats = getStatusRowData(rowPlan + 4);  // ANTRI
    var finishStats = getStatusRowData(rowPlan + 5); // FINISH

    var cbmPlanRow = values[rowPlan + 8] || [];
    var cbmRealRow = values[rowPlan + 9] || [];
    var cbmPlanTotal = Number(cbmPlanRow[14]) || 55;
    var cbmRealTotal = Number(cbmRealRow[14]) || 55;

    var rowCbmStok = findRowByLabel("CBM STOK");
    if (rowCbmStok === -1) rowCbmStok = 24;
    
    var cbmStokVal = Number(values[rowCbmStok] ? values[rowCbmStok][3] : 0) || 55;
    var cbmTransitVal = Number(values[rowCbmStok + 1] ? values[rowCbmStok + 1][3] : 0) || 192.5;
    var cbmTotalVal = Number(values[rowCbmStok + 2] ? values[rowCbmStok + 2][3] : 0) || 247.5;

    var rowPutaway = findRowByLabel("PUTAWAY STOK STAGING TO FLOOR STORING");
    if (rowPutaway === -1) rowPutaway = 28;

    var area1Plan = Number(values[rowPutaway + 3] ? values[rowPutaway + 3][3] : 0) || 36;
    var area2Plan = Number(values[rowPutaway + 4] ? values[rowPutaway + 4][3] : 0) || 61;
    var area3Plan = Number(values[rowPutaway + 5] ? values[rowPutaway + 5][3] : 0) || 64;

    var widgets = {
      periodeBulan: "May 2026",
      updateDate: "16-Jun-2026",
      etaCont: etaCont,
      contReceiveDc: contReceiveDc,
      planToday: planToday,
      totalContainer: etaCont,
      contBelumGetIn: belumStats.total,
      contAtPort: antriStats.total,
      prosesPib: prosesStats.total,
      prosesClearance: area1Plan,
      contSppb: area2Plan,
      readyToPlan: area3Plan,
      contFreeTime: cbmStokVal,
      contStorage: cbmTransitVal,
      belumSppb: belumStats.total,
      dokumenBelumLengkap: actualReceivedDc,
      sppbJalurMerah: planToday,
      contFreeStorage: cbmTotalVal,
      contDemurage: 0
    };

    var forecast = {
      actualReceivedDc: actualReceivedDc,
      planToDc: planToday,
      containerAtTanjungPerak: cbmTotalVal,
      containerSppbReadyDc: cbmTransitVal
    };

    var aging = {
      zeroDays: area1Plan,
      sixToTen: area2Plan,
      elevenToFifteen: area3Plan,
      sixteenToTwentyOne: cbmStokVal,
      twentyTwoToThirty: cbmTransitVal,
      moreThanThirty: cbmTotalVal,
      total: cbmTotalVal
    };

    var status_26 = [{
      bulan: "May 2026",
      received: contReceiveDc,
      rencana_masuk: etaCont,
      proses_clearance: prosesStats.total,
      rencana_bayar: antriStats.total,
      total: etaCont
    }];

    var penitipan_26 = [{
      bulan: "May 2026",
      in: planToday,
      done: actualReceivedDc,
      sisa: Math.max(0, planToday - actualReceivedDc)
    }];

    var demurrage_26 = [{
      bulan: "May 2026",
      received: actualReceivedDc,
      storage: cbmStokVal,
      demurrage: cbmTransitVal,
      total: cbmTotalVal
    }];

    return {
      penitipan_24_25: penitipan_24_25.length > 0 ? penitipan_24_25 : null,
      status_24_25: status_24_25.length > 0 ? status_24_25 : null,
      demurrage_24_25: demurrage_24_25.length > 0 ? demurrage_24_25 : null,
      penitipan_26: penitipan_26,
      status_26: status_26,
      demurrage_26: demurrage_26,
      widgets: widgets,
      forecast: forecast,
      aging: aging
    };
  } catch (e) {
    console.error("Gagal parse container values: " + e.toString());
    return null;
  }
}

function getStoringAreaData() {
  const SS_ID = "1EZs5IJFcvYRPk49dWbBz0wdh3Iyk2ikUorGgUXkgdKE";
  try {
    const ss = SpreadsheetApp.openById(SS_ID);
    if (!ss) return null;
    const result = {};
    const sheets = ss.getSheets();
    for (let i = 0; i < sheets.length; i++) {
      const sh = sheets[i];
      const name = sh.getName();
      result[name] = sh.getDataRange().getValues();
    }
    return result;
  } catch (e) {
    console.error("Gagal mengambil data Storing Area: " + e.toString());
    return null;
  }
}

function getOutboundData() {
  const OUTBOUND_SS_ID = "18lPFvtS2mnhHpRpE-AlKqVn_v541AxfLvUsFaEaih8o";
  const GID = "741699408";
  try {
    let ss = null;
    try {
      ss = SpreadsheetApp.openById(OUTBOUND_SS_ID);
    } catch (e) {
      console.warn("Gagal membuka Outbound SS by ID, mencoba active spreadsheet: " + e.message);
      ss = SpreadsheetApp.getActiveSpreadsheet();
    }
    if (!ss) return [];
    
    const sheets = ss.getSheets();
    let sh = null;
    for (let i = 0; i < sheets.length; i++) {
      if (sheets[i].getSheetId().toString() === GID) {
        sh = sheets[i];
        break;
      }
    }
    if (!sh) sh = sheets[0];
    
    const grid = sh.getDataRange().getValues();
    if (!grid || grid.length <= 1) return [];
    
    // Find the header row
    let headerRowIdx = -1;
    for (let r = 0; r < Math.min(grid.length, 15); r++) {
      const row = grid[r];
      if (row && row.length > 0) {
        const rowStr = row.map(cell => String(cell || "").toUpperCase().trim());
        if (rowStr.includes("NO LC") || rowStr.includes("MANIFEST") || rowStr.some(cell => cell.includes("JALUR") || cell.includes("RUTE") || cell.includes("STATUS") || cell.includes("DOOR") || cell.includes("STUFFING"))) {
          headerRowIdx = r;
          break;
        }
      }
    }
    
    if (headerRowIdx === -1) {
      headerRowIdx = 0;
    }
    
    const headerRow = grid[headerRowIdx];
    const colMap = {
      manifest: -1, jalur: -1, leader: -1, shift: -1, door: -1, status: -1,
      checkin: -1, openLoad: -1, closeLoad: -1, checkout: -1, vendor: -1, armada: -1, stuffing: -1, area: -1
    };
    
    // Map standard column indexes dynamically
    for (let c = 0; c < headerRow.length; c++) {
      const hVal = String(headerRow[c] || "").toUpperCase().trim();
      if (hVal === "NO LC" || hVal === "MANIFEST" || hVal === "NO. LC" || hVal === "LC") colMap.manifest = c;
      else if (hVal.includes("JALUR") || hVal === "RUTE" || hVal.includes("DESTINATION") || hVal.includes("TUJUAN") || hVal.includes("CORRIDOR")) colMap.jalur = c;
      else if (hVal.includes("DRIVER") || hVal.includes("LEADER") || hVal.includes("SOPIR") || hVal.includes("SOPIR/LEADER")) colMap.leader = c;
      else if (hVal.includes("SHIFT")) colMap.shift = c;
      else if (hVal.includes("DOOR") || hVal.includes("PINTU")) colMap.door = c;
      else if (hVal.includes("STATUS") || hVal.includes("STATE") || hVal.includes("KETERANGAN")) colMap.status = c;
      else if (hVal.includes("CHECK") && hVal.includes("IN")) colMap.checkin = c;
      else if (hVal.includes("OPEN") || hVal.includes("MULAI") || hVal.includes("START")) colMap.openLoad = c;
      else if (hVal.includes("CLOSE") || hVal.includes("SELESAI") || hVal.includes("FINISH")) colMap.closeLoad = c;
      else if (hVal.includes("CHECK") && hVal.includes("OUT")) colMap.checkout = c;
      else if (hVal.includes("VENDOR") || hVal.includes("REKANAN") || hVal.includes("EXPEDISI") || hVal.includes("FORWARDER")) colMap.vendor = c;
      else if (hVal.includes("ARMADA") || hVal.includes("KENDARAAN") || hVal.includes("JENIS") || hVal.includes("TRUCK")) colMap.armada = c;
      else if (hVal.includes("STUFFING") || hVal.includes("LOADING %") || hVal.includes("PERSEN") || hVal.includes("LOADING")) colMap.stuffing = c;
      else if (hVal.includes("AREA") || hVal.includes("WILAYAH") || hVal.includes("SEKTOR") || hVal.includes("DISTRICT")) colMap.area = c;
    }
    
    // Fallback defaults in case header labels differ
    if (colMap.manifest === -1) {
      for (let c = 0; c < headerRow.length; c++) {
        if (String(headerRow[c]).toUpperCase().includes("LC")) { colMap.manifest = c; break; }
      }
      if (colMap.manifest === -1) colMap.manifest = 0;
    }
    if (colMap.jalur === -1) {
      for (let c = 0; c < headerRow.length; c++) {
        const u = String(headerRow[c]).toUpperCase();
        if (u.includes("DEST") || u.includes("RUTE") || u.includes("TUJUAN") || u.includes("KORIDOR") || u.includes("CITY")) { colMap.jalur = c; break; }
      }
      if (colMap.jalur === -1) colMap.jalur = Math.min(1, headerRow.length - 1);
    }
    if (colMap.leader === -1) {
      for (let c = 0; c < headerRow.length; c++) {
        const u = String(headerRow[c]).toUpperCase();
        if (u.includes("SOPIR") || u.includes("DRIV") || u.includes("LEAD")) { colMap.leader = c; break; }
      }
      if (colMap.leader === -1) colMap.leader = Math.min(2, headerRow.length - 1);
    }
    if (colMap.shift === -1) {
      for (let c = 0; c < headerRow.length; c++) {
        if (String(headerRow[c]).toUpperCase().includes("SHIFT")) { colMap.shift = c; break; }
      }
      if (colMap.shift === -1) colMap.shift = Math.min(3, headerRow.length - 1);
    }
    if (colMap.door === -1) {
      for (let c = 0; c < headerRow.length; c++) {
        const u = String(headerRow[c]).toUpperCase();
        if (u.includes("DOOR") || u.includes("PINTU") || u.includes("GATE")) { colMap.door = c; break; }
      }
      if (colMap.door === -1) colMap.door = Math.min(4, headerRow.length - 1);
    }
    if (colMap.status === -1) {
      for (let c = 0; c < headerRow.length; c++) {
        const u = String(headerRow[c]).toUpperCase();
        if (u.includes("STAT") || u.includes("KET")) { colMap.status = c; break; }
      }
      if (colMap.status === -1) colMap.status = Math.min(5, headerRow.length - 1);
    }
    if (colMap.checkin === -1) {
      for (let c = 0; c < headerRow.length; c++) {
        if (String(headerRow[c]).toUpperCase().includes("IN")) { colMap.checkin = c; break; }
      }
      if (colMap.checkin === -1) colMap.checkin = Math.min(6, headerRow.length - 1);
    }
    if (colMap.openLoad === -1) {
      for (let c = 0; c < headerRow.length; c++) {
        const u = String(headerRow[c]).toUpperCase();
        if (u.includes("OPEN") || u.includes("MULAI") || u.includes("START")) { colMap.openLoad = c; break; }
      }
      if (colMap.openLoad === -1) colMap.openLoad = Math.min(7, headerRow.length - 1);
    }
    if (colMap.closeLoad === -1) {
      for (let c = 0; c < headerRow.length; c++) {
        const u = String(headerRow[c]).toUpperCase();
        if (u.includes("CLOSE") || u.includes("SELESAI") || u.includes("FINISH")) { colMap.closeLoad = c; break; }
      }
      if (colMap.closeLoad === -1) colMap.closeLoad = Math.min(8, headerRow.length - 1);
    }
    if (colMap.checkout === -1) {
      for (let c = 0; c < headerRow.length; c++) {
        if (String(headerRow[c]).toUpperCase().includes("OUT")) { colMap.checkout = c; break; }
      }
      if (colMap.checkout === -1) colMap.checkout = Math.min(9, headerRow.length - 1);
    }
    if (colMap.vendor === -1) {
      for (let c = 0; c < headerRow.length; c++) {
        const u = String(headerRow[c]).toUpperCase();
        if (u.includes("VEND") || u.includes("EXP") || u.includes("REK")) { colMap.vendor = c; break; }
      }
      if (colMap.vendor === -1) colMap.vendor = Math.min(10, headerRow.length - 1);
    }
    if (colMap.armada === -1) {
      for (let c = 0; c < headerRow.length; c++) {
        const u = String(headerRow[c]).toUpperCase();
        if (u.includes("ARM") || u.includes("MOB") || u.includes("TRUCK") || u.includes("JENIS") || u.includes("KEND")) { colMap.armada = c; break; }
      }
      if (colMap.armada === -1) colMap.armada = Math.min(11, headerRow.length - 1);
    }
    if (colMap.stuffing === -1) {
      for (let c = 0; c < headerRow.length; c++) {
        const u = String(headerRow[c]).toUpperCase();
        if (u.includes("STU") || u.includes("%") || u.includes("LOAD")) { colMap.stuffing = c; break; }
      }
      if (colMap.stuffing === -1) colMap.stuffing = Math.min(12, headerRow.length - 1);
    }
    if (colMap.area === -1) {
      for (let c = 0; c < headerRow.length; c++) {
        const u = String(headerRow[c]).toUpperCase();
        if (u.includes("AREA") || u.includes("WIL") || u.includes("SEK")) { colMap.area = c; break; }
      }
      if (colMap.area === -1) colMap.area = Math.min(13, headerRow.length - 1);
    }
    
    const manifestList = [];
    for (let r = headerRowIdx + 1; r < grid.length; r++) {
      const row = grid[r];
      if (row && row.length > 0) {
        const manifest = String(row[colMap.manifest] || "").trim();
        if (manifest && manifest !== "-" && manifest !== "#N/A" && manifest !== "TOTAL" && manifest.toUpperCase() !== "NO LC" && manifest.toUpperCase() !== "MANIFEST" && manifest !== "0") {
          manifestList.push({
            manifest: manifest,
            destination: colMap.jalur !== -1 ? String(row[colMap.jalur] || "").trim() : "",
            jalur: colMap.jalur !== -1 ? String(row[colMap.jalur] || "").trim() : "",
            leader: colMap.leader !== -1 ? String(row[colMap.leader] || "").trim() : "",
            shift: colMap.shift !== -1 ? String(row[colMap.shift] || "").trim() : "",
            door: colMap.door !== -1 ? String(row[colMap.door] || "").trim() : "",
            status: colMap.status !== -1 ? String(row[colMap.status] || "").trim() : "",
            checkin: colMap.checkin !== -1 ? String(row[colMap.checkin] || "").trim() : "",
            openLoad: colMap.openLoad !== -1 ? String(row[colMap.openLoad] || "").trim() : "",
            closeLoad: colMap.closeLoad !== -1 ? String(row[colMap.closeLoad] || "").trim() : "",
            checkout: colMap.checkout !== -1 ? String(row[colMap.checkout] || "").trim() : "",
            vendor: colMap.vendor !== -1 ? String(row[colMap.vendor] || "").trim() : "",
            armada: colMap.armada !== -1 ? String(row[colMap.armada] || "").trim() : "",
            stuffing: colMap.stuffing !== -1 ? String(row[colMap.stuffing] || "").trim() : "",
            area: colMap.area !== -1 ? String(row[colMap.area] || "").trim() : ""
          });
        }
      }
    }
    return manifestList;
  } catch (e) {
    console.error("Outbound retrieval failed for ID 18lPFvtS2mnhHpRpE-AlKqVn_v541AxfLvUsFaEaih8o: " + e.toString());
    return [];
  }
}

// ================= AUTOMATIC TRIGGERS & REAL-TIME SYNC =================

// Trigger onEdit: Runs automatically when a cell is edited in the Google Spreadsheet simple interface
function onEdit(e) {
  try {
    handleSpreadsheetEdit(e || null);
  } catch (err) {
    console.error("onEdit failed to execute: " + err.toString());
  }
}

// Trigger onChange: Runs automatically when structural changes occur (pasting large tables, deleting rows, inserting sheets)
function onChange(e) {
  try {
    handleSpreadsheetEdit(null);
  } catch (err) {
    console.error("onChange failed to execute: " + err.toString());
  }
}

// Trigger onOpen: Generates a custom menu inside the Spreadsheet interface for easy control
function onOpen() {
  try {
    const ui = SpreadsheetApp.getUi();
    ui.createMenu('NDC Sidoarjo CC')
      .addItem('Manual Sync Dashboard Data', 'manualSyncDashboardData')
      .addItem('Open Web App Dashboard', 'openDashboardUrl')
      .addToUi();
  } catch(e) {
    console.log("Spreadsheet UI Menu generation omitted (running outside of active sheet editor context): " + e.toString());
  }
}

// Performs an on-demand spreadsheet sync and notifies the user with dynamic UI toast messages
function manualSyncDashboardData() {
  try {
    const ss = SpreadsheetApp.getActiveSpreadsheet() || getSS();
    if (ss) {
      ss.toast("Memulai sinkronisasi data dengan server...", "Dashboard Sync", 3);
    }
    
    // Regenerate summaries manually
    generateSummary();
    try { generateAging(); } catch(err) {}
    
    // Refresh modified tracking state
    updateLastUpdateTimestamp();
    
    if (ss) {
      ss.toast("Sinkronisasi berhasil! Semua layar dashboard akan segera di-update.", "Dashboard Sync", 6);
    }
  } catch (e) {
    console.error("Manual sync failed: " + e.toString());
    try {
      SpreadsheetApp.getUi().alert("Gagal melakukan registrasi sync: " + e.toString());
    } catch(err) {}
  }
}

// Show HTML popup helper that automatically launches the companion Web App
function openDashboardUrl() {
  try {
    const url = ScriptApp.getService().getUrl();
    if (url) {
      const html = "<script>window.open('" + url + "', '_blank');google.script.host.close();</script>Membuka dashboard...";
      const userInterface = HtmlService.createHtmlOutput(html)
        .setWidth(320)
        .setHeight(90);
      SpreadsheetApp.getUi().showModalDialog(userInterface, "Membuka Dashboard...");
    } else {
      SpreadsheetApp.getUi().alert("Web App URL belum aktif. Harap deploy project ini sebagai Web App di menu Deploy > New Deployment.");
    }
  } catch(e) {
    console.warn("Unable to fetch active service context or open dialog: " + e.toString());
  }
}

// Unified controller that manages passive data calculations and stamps revision trackers
function handleSpreadsheetEdit(e) {
  let sheetName = "";
  if (e && e.range) {
    try {
      sheetName = e.range.getSheet().getName();
    } catch(err) {}
  }
  
  console.log("Spreadsheet automatic recalculation triggered. Active sheet: " + sheetName);
  
  // Re-calculate the Inbound and Plan summary sheets
  try {
    generateSummary();
  } catch(err) {
    console.warn("Auto-summary regeneration deferred: " + err.toString());
  }
  
  // Re-calculate container statistics
  try {
    generateAging();
  } catch(err) {
    console.warn("Auto-aging calculations deferred: " + err.toString());
  }
  
  // Write the modification stamp
  updateLastUpdateTimestamp();
}

// Persistent revision state writer
function updateLastUpdateTimestamp() {
  try {
    const timestamp = new Date().getTime().toString();
    
    // Persist timestamp inside ScriptProperties for lightweight state polling
    PropertiesService.getScriptProperties().setProperty('LAST_UPDATE', timestamp);
    
    // Cache inside ScriptCache for instant returns without Property Service consumption quota
    try {
      CacheService.getScriptCache().put('LAST_UPDATE', timestamp, 21600); // Live for 6 hours
    } catch(_) {}
    
    // Also save visually inside Cell G1 and H1 of SUMMARY sheet for offline-to-online compatibility
    try {
      const sh = getSheet(S_SUM);
      if (sh) {
        // We write to standard columns out of normal table range (G and H)
        sh.getRange("G1").setValue("LAST_UPDATE_TIMESTAMP");
        sh.getRange("H1").setValue(timestamp);
        
        const friendlyTime = Utilities.formatDate(new Date(), Session.getScriptTimeZone() || "GMT+7", "dd-MMM-yyyy HH:mm:ss");
        sh.getRange("G2").setValue("LAST_UPDATE_FRIENDLY");
        sh.getRange("H2").setValue(friendlyTime);
      }
    } catch(err) {
      console.warn("Visual sheet timestamp persistence skipped: " + err.toString());
    }
  } catch(e) {
    console.error("Critical error in updateLastUpdateTimestamp: " + e.toString());
  }
}

// Exposes a lightweight function for our HTML/JS dashboard to query every 15 seconds.
// This is much faster and cheaper than running the full heavy getAllData() query.
function checkLastUpdate(clientTimestamp) {
  try {
    let last = null;
    
    // Attempt to compute the composite dynamic stamp from lastUpdateTime of all associated sheets
    try {
      let stamps = [];
      
      // 1. Core script LAST_UPDATE property
      try {
        const lastProp = PropertiesService.getScriptProperties().getProperty('LAST_UPDATE');
        if (lastProp) stamps.push(lastProp);
      } catch(_) {}
      
      // 2. Main Spreadsheet ID (active)
      try {
        const ssId = SpreadsheetApp.getActiveSpreadsheet().getId();
        const updated = DriveApp.getFileById(ssId).getLastUpdated().getTime().toString();
        stamps.push(updated);
      } catch(_) {}

      // 3. Outbound Spreadsheet ID
      try {
        const OUTBOUND_SS_ID = "18lPFvtS2mnhHpRpE-AlKqVn_v541AxfLvUsFaEaih8o";
        const updated = DriveApp.getFileById(OUTBOUND_SS_ID).getLastUpdated().getTime().toString();
        stamps.push(updated);
      } catch(_) {}

      // 4. Sidoarjo Snd/Bcklg ID
      try {
        const SIDOARJO_SS_ID = "1TZCErmnxYJ_zgt3smi0V60plJKxbsnTLxlpw6qEGuNA";
        const updated = DriveApp.getFileById(SIDOARJO_SS_ID).getLastUpdated().getTime().toString();
        stamps.push(updated);
      } catch(_) {}

      // 5. Container Monitoring ID
      try {
        const CONTAINER_SS_ID = "1qVzs2vJu2i00MMX3HsM94YMdAG2fr6JRbANZJjuE754";
        const updated = DriveApp.getFileById(CONTAINER_SS_ID).getLastUpdated().getTime().toString();
        stamps.push(updated);
      } catch(_) {}

      // 6. Storing Area ID
      try {
        const STORING_SS_ID = "1EZs5IJFcvYRPk49dWbBz0wdh3Iyk2ikUorGgUXkgdKE";
        const updated = DriveApp.getFileById(STORING_SS_ID).getLastUpdated().getTime().toString();
        stamps.push(updated);
      } catch(_) {}

      if (stamps.length > 0) {
        last = stamps.join("_");
      }
    } catch(driveErr) {
      console.warn("DriveApp composite timestamp failed: " + driveErr.toString());
    }
    
    if (!last) {
      // 1. Check cache first for rapid fulfillment
      try {
        last = CacheService.getScriptCache().get('LAST_UPDATE');
      } catch(_) {}
      
      // 2. Fallback to properties service
      if (!last) {
        try {
          last = PropertiesService.getScriptProperties().getProperty('LAST_UPDATE');
        } catch(_) {}
      }
      
      // 3. Fallback to reading the visual cells
      if (!last) {
        try {
          const sh = getSheet(S_SUM);
          if (sh) {
            last = String(sh.getRange("H1").getValue() || "").trim();
          }
        } catch(_) {}
      }
    }
    
    if (!last) {
      last = "0";
    }
    
    const clientStr = String(clientTimestamp || "").trim();
    if (clientStr && clientStr !== last) {
      return { hasUpdate: true, timestamp: last };
    }
    return { hasUpdate: false, timestamp: last };
  } catch(e) {
    // If checking fails, tell the client to refresh just in case
    return { hasUpdate: true, timestamp: new Date().getTime().toString() };
  }
}


import { defineConfig } from 'vite';
import https from 'https';
import { IncomingMessage } from 'http';

function fetchUrlWithRedirects(targetUrl: string, maxRedirects = 5): Promise<{ statusCode: number; headers: any; text: string }> {
  return new Promise((resolve, reject) => {
    https.get(targetUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
      }
    }, (res: IncomingMessage) => {
      const statusCode = res.statusCode || 200;
      if (statusCode >= 300 && statusCode < 400 && res.headers.location) {
        if (maxRedirects <= 0) {
          reject(new Error('Too many redirects'));
          return;
        }
        resolve(fetchUrlWithRedirects(res.headers.location, maxRedirects - 1));
        return;
      }

      let data = '';
      res.on('data', chunk => {
        data += chunk;
      });
      res.on('end', () => {
        resolve({ statusCode, headers: res.headers, text: data });
      });
    }).on('error', err => {
      reject(err);
    });
  });
}

export default defineConfig({
  server: {
    port: 3000,
    strictPort: true,
    host: true,
    configureServer(server) {
      server.middlewares.use('/api/proxy-sheet', async (req, res) => {
        try {
          const urlObj = new URL(req.url || '', `http://${req.headers.host}`);
          const spreadsheetId = urlObj.searchParams.get('id');
          const gid = urlObj.searchParams.get('gid');
          const sheet = urlObj.searchParams.get('sheet');
          const reqType = urlObj.searchParams.get('type') || 'gviz';

          if (!spreadsheetId) {
            res.statusCode = 400;
            res.end('Missing spreadsheet id');
            return;
          }

          let targetUrl = '';
          if (reqType === 'export') {
            targetUrl = `https://docs.google.com/spreadsheets/d/${spreadsheetId}/export?format=csv`;
            if (gid) {
              targetUrl += `&gid=${gid}`;
            } else if (sheet) {
              targetUrl += `&sheet=${encodeURIComponent(sheet)}`;
            }
          } else {
            targetUrl = `https://docs.google.com/spreadsheets/d/${spreadsheetId}/gviz/tq?tqx=out:csv`;
            if (gid) {
              targetUrl += `&gid=${gid}`;
            } else if (sheet) {
              targetUrl += `&sheet=${encodeURIComponent(sheet)}`;
            }
          }

          const result = await fetchUrlWithRedirects(targetUrl);
          res.setHeader('Access-Control-Allow-Origin', '*');
          res.setHeader('Content-Type', 'text/csv; charset=utf-8');
          res.statusCode = result.statusCode;
          res.end(result.text);
        } catch (err: any) {
          res.statusCode = 500;
          res.end(`Proxy error: ${err.message}`);
        }
      });
    }
  }
});

import https from 'https';
import { IncomingMessage } from 'http';

function fetchUrlWithRedirects(targetUrl: string, maxRedirects = 5): Promise<{ statusCode: number; headers: any; text: string }> {
  return new Promise((resolve, reject) => {
    https.get(targetUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
      }
    }, (res: IncomingMessage) => {
      const statusCode = res.statusCode || 200;
      if (statusCode >= 300 && statusCode < 400 && res.headers.location) {
        if (maxRedirects <= 0) {
          reject(new Error('Too many redirects'));
          return;
        }
        resolve(fetchUrlWithRedirects(res.headers.location, maxRedirects - 1));
        return;
      }

      let data = '';
      res.on('data', chunk => {
        data += chunk;
      });
      res.on('end', () => {
        resolve({ statusCode, headers: res.headers, text: data });
      });
    }).on('error', err => {
      reject(err);
    });
  });
}

async function main() {
  const SIDOARJO_IDS = [
    "1TZCErmnxYJ_zgt3smi0V60plJKxbsnTLxlpw6qEGuNA", // Sidoarjo Demand & Backlog
    "19Gm8hgM2qff96HZPAJ2DOKDMYBgZKxOTL7X00-bQoWM", // Sidoarjo Container Monitoring
    "1EZs5IJFcvYRPk49dWbBz0wdh3Iyk2ikUorGgUXkgdKE"  // Sidoarjo Storing Area
  ];

  console.log("--- START TESTING SHEET TABS WITH REDIRECTS ---");
  for (const id of SIDOARJO_IDS) {
    console.log(`\nSpreadsheet: ${id}`);
    
    // Check main export
    try {
      const res = await fetchUrlWithRedirects(`https://docs.google.com/spreadsheets/d/${id}/export?format=csv`);
      const lines = res.text.split('\n');
      console.log(`- Default Sheet: ${lines.length} lines. First 3 lines:`);
      console.log(lines.slice(0, 3).join('\n'));
    } catch (e: any) {
      console.log(`- Default Sheet failed: ${e.message}`);
    }

    // Try some common tab names
    const commonTabs = ["Outbound", "OUTBOUND", "Outbound Activity", "OUTBOUND ACTIVITY", "Daily Plan", "DAILY PLAN", "Detail Outbound", "Outbound_Activity"];
    for (const tab of commonTabs) {
      try {
        const res = await fetchUrlWithRedirects(`https://docs.google.com/spreadsheets/d/${id}/export?format=csv&sheet=${encodeURIComponent(tab)}`);
        const csv = res.text;
        if (csv && csv.trim() && !csv.includes("<!DOCTYPE") && !csv.includes("HtmlService") && !csv.includes("Temporary Redirect")) {
          const lines = csv.split('\n');
          console.log(`- Tab [${tab}]: FOUND! ${lines.length} lines. First 3 lines:`);
          console.log(lines.slice(0, 3).join('\n'));
        }
      } catch (e: any) {}
    }
  }
}

main();
